import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot, UrlTree } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RutaProtegidaGuard implements CanActivate {
  asdf: ToastController = new ToastController()

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      return this.validarAcceso();
  }
  validarAcceso()
  {

    this.presentToast();
    return true;

  }
  async presentToast() {
    const toast = await this.asdf.create({
      message: 'Acceso no permitido!!!',
      duration: 1500,
      position: 'top'
    });

    await toast.present();
  }
}
