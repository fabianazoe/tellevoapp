import { Injectable } from '@angular/core';
import { Storage } from '@ionic/storage-angular';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DbService {


 
    private _storage: Storage| null = null;

    constructor(private storage: Storage) { 
      this.init();
    }
  
    async guardarDatos(key: string, value: string){
      await this.storage.set(key ,value);
    }
  
    async verDatos(key: string): Promise<any>{
      const nombre = await this.storage.get(key);
      return nombre;
  
    }
  
    async init(){
  
      const storage = await this.storage.create();
      this._storage = storage;
    }
  
  
   // Crear y exponer métodos que los usuarios de este servicio puedan
    // llamar, por ejemplo:
  
    public set(key: string, value: any){
      this._storage?.set(key, value);
    }
  
  
  }
 
