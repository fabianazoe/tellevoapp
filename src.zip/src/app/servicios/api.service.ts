import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { identity, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  constructor(private http: HttpClient) { }

  apiURL ="https://duoc.grupodevcon.cl/API/v2/"
  apiToken = "03"

  crearUsuario(nombre: string, rut: string, apellidos: string, correo: string, password: string, tipo_usuario:any): Observable<any>{
    let dataBody = {
      "nombre": nombre,
      "rut": rut,
      "apellidos": apellidos,
      "correo": correo,
      "password": password,
      "tipo_usuario": tipo_usuario,
      "token_alumno": this.apiToken
    }
    return this.http.post(this.apiURL + "crearUsuario", dataBody).pipe();
  }

  crearViaje(id_viaje: string, destino: string, monto_por_persona: string, total_pasajeros: string, latitud: string, longitud: string, asientos_disponibles: string): Observable<any>{
    let Body = {
      "id_viaje": id_viaje,
      "destino": destino,
      "monto_por_persona": monto_por_persona,
      "total_pasajeros": total_pasajeros,
      "asientos_disponibles": asientos_disponibles,
      "latitud": latitud,
      "longitud": longitud,
      "token": this.apiToken
    }
    return this.http.post(this.apiURL + "crearViaje", Body).pipe(); 
  }

  loginUsuario( correo: string, password: string): Observable<any>{
    let data = {
      "correo": correo,
      "password": password,
      "token_alumno": this.apiToken

    }
    return this.http.post(this.apiURL + "loginUsuario", data).pipe();
  }

  recuperarPassword( correo: string){
    let datos = {
      "correo": correo,
      "token_alumno": this.apiToken

    }
    return this.http.post(this.apiURL + "recuperarPassword", datos).pipe();
  }

  obtenerUsuarios():Observable<any>
  {
    return this.http.get(this.apiURL + "obtenerUsuarios/" + this.apiToken).pipe(); 

  }
  obtenerViajes():Observable<any>
  {
    return this.http.get(this.apiURL + "obtenerViajes/" + this.apiToken).pipe(); 

  }
  agregarPasajero(id_viaje : string, id_pasajero : string):Observable<any>
  {
    return this.http.get(this.apiURL + "agregarPasajero/" + id_viaje + id_pasajero).pipe(); 

  }
  obtenerPasajeros(id_viaje : string):Observable<any>
  {
    return this.http.get(this.apiURL + "obtenerPasajeros/" + id_viaje).pipe(); 

  }
  eliminarViaje(id_viaje : string): Observable<any>
  {
    return this.http.delete(this.apiURL + "eliminarViaje/"+ id_viaje).pipe();
  }
  eliminarPasajero(id_viaje : string, id : string): Observable<any>
  {
    return this.http.delete(this.apiURL + "eliminarPasajero/"+ id_viaje + id).pipe();
  }

  
}
