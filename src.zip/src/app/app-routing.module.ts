import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./page/home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'rcontrasena',
    loadChildren: () => import('./page/rcontrasena/rcontrasena.module').then( m => m.RcontrasenaPageModule)
  },
  {
    path: 'bienvenido',
    loadChildren: () => import('./page/bienvenido/bienvenido.module').then( m => m.BienvenidoPageModule)
  },
  {
    path: 'registro',
    loadChildren: () => import('./page/registro/registro.module').then( m => m.RegistroPageModule)
  },
  {
    path: 'not-found',
    loadChildren: () => import('./page/not-found/not-found.module').then( m => m.NotFoundPageModule)
  },
  {
    path: 'ingresar',
    loadChildren: () => import('./page/ingresar/ingresar.module').then( m => m.IngresarPageModule)
  },
  {
    path: 'conductor',
    loadChildren: () => import('./page/conductor/conductor.module').then( m => m.ConductorPageModule)
  },
  {
    path: 'pasajero',
    loadChildren: () => import('./page/pasajero/pasajero.module').then( m => m.PasajeroPageModule)
  },
  {
    path: 'viajes',
    loadChildren: () => import('./page/viajes/viajes.module').then( m => m.ViajesPageModule)
  },
  {
    path: 'bienvenidopasajero',
    loadChildren: () => import('./page/bienvenidopasajero/bienvenidopasajero.module').then( m => m.BienvenidopasajeroPageModule)
  },
  {
    path: 'ingresarpasajero',
    loadChildren: () => import('./page/ingresarpasajero/ingresarpasajero.module').then( m => m.IngresarpasajeroPageModule)
  },
  {
    path:'**',
    redirectTo: 'not-found',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
