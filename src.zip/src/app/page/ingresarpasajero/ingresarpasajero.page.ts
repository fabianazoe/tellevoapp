import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ApiService } from 'src/app/servicios/api.service';
import { DbService } from 'src/app/servicios/db.service';
//import { Geolocation } from '@capacitor/geolocation';
import { ToastController } from '@ionic/angular';

@Component({
  selector: 'app-ingresarpasajero',
  templateUrl: './ingresarpasajero.page.html',
  styleUrls: ['./ingresarpasajero.page.scss'],
})
export class IngresarpasajeroPage implements OnInit {

  formLogin = {
    correo: "",
    password: "",
    tipo_usuario: "",

  }
  mensaje:String;
  miModelo: any;



   constructor(private api : ApiService, private router: Router, private alertController: AlertController, private db: DbService, private toastController: ToastController) {
    this.mensaje = "BIENVENIDO";
  }
  ingresar()
  {
    var correo= this.formLogin.correo;

    let datosEnviar: NavigationExtras = {
      queryParams: {correos: correo}
    }
    this.router.navigate(['/bienvenidopasajero'], datosEnviar)
  }
  ngOnInit() {this.miModelo = {
  };
  }

  guardarDatos(){}

  inicioSesion(){
    this.api.loginUsuario(this.formLogin.correo,this.formLogin.password).subscribe((response)=>{
        console.log(response);

        this.ingresar()
        if(response.result == 'Login correcto' ){

          console.log(response)
          
        this.alerta('middle', response.result);

        }else(this.alerta('middle', response.result) ,console.log(response.result)  ) 
      
      }
    )
  }


     //mensaje de alerta
     async alerta(position: 'top' | 'middle' | 'bottom', mensajito: string) {
      const toast = await this.toastController.create({
        message: mensajito,
        duration: 2500,
        position: position
      });
  
      await toast.present();
    }
  

  tipoUser(){
    const tipoUser = localStorage.getItem('tipo_usuario');
    if ( tipoUser === 'conductor' ){
      this.router.navigate(['/bienvenido']);
    }else if ( tipoUser === 'pasajero' ){
      this.router.navigate(['/bienvenidopasajero'])
    }
  }

  




}

