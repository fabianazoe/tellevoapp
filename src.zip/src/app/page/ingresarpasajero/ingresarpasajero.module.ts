import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { IngresarpasajeroPageRoutingModule } from './ingresarpasajero-routing.module';

import { IngresarpasajeroPage } from './ingresarpasajero.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    IngresarpasajeroPageRoutingModule
  ],
  declarations: [IngresarpasajeroPage]
})
export class IngresarpasajeroPageModule {}
