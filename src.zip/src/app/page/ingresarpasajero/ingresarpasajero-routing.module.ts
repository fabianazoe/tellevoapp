import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { IngresarpasajeroPage } from './ingresarpasajero.page';

const routes: Routes = [
  {
    path: '',
    component: IngresarpasajeroPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class IngresarpasajeroPageRoutingModule {}
