import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ApiService } from 'src/app/servicios/api.service';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.page.html',
  styleUrls: ['./registro.page.scss'],
})
export class RegistroPage implements OnInit {

  formRegistro = {
    nombre: "",
    rut: "",
    apellidos: "",
    correo: "",
    password: "",
    tipo_usuario: "",

  }

  miModelo: any;

  constructor(private api: ApiService, private alertController: AlertController, private router : Router) { }
  

  ngOnInit() {this.miModelo = {
  };
  }
  crearUsuario()
  {
    this.api.crearUsuario(this.formRegistro.nombre, this.formRegistro.rut,
      this.formRegistro.apellidos,
      this.formRegistro.correo,
      this.formRegistro.password, this.formRegistro.tipo_usuario).subscribe((response)=>{
        console.log(response)

      if(response.result == "usuario creado con exito" ){
            
        this.alerta1()

      }else(alert('usuario creado con exito'), this.router.navigate(['/ingresar']), console.log(response.result) )

    })
}

//alerta
async alerta1(){
const alert = await this.alertController.create({
  header: 'Usuario Registrado Correctamente!',
  subHeader: '',
  message: 'presiona OK para continuar',
  buttons: ['OK'],
});
await alert.present();
this.router.navigate(['/ingresar'])
      
}
}
