import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { ApiService } from 'src/app/servicios/api.service';

@Component({
  selector: 'app-viajes',
  templateUrl: './viajes.page.html',
  styleUrls: ['./viajes.page.scss'],
})
export class ViajesPage implements OnInit {

  listaPasajeros: any[] = []
  listaViajes: any[] = []
  constructor(private api : ApiService, private toastController: ToastController, private router: Router) { }

  
  ngOnInit() {
    this.obtenerViajes()
  }

  obtenerViajes()
  {
    this.api.obtenerViajes().subscribe((respuesta)=>{
      console.log(respuesta);
      if(respuesta.viajes == "No hay ningun viaje creado")
      {
        //mostrar un error
        this.presentToast('middle', respuesta.viajes)
      }
      else{
        this.listaViajes = respuesta.viajes;
        }
    
    })
  }


  async presentToast(position: 'top' | 'middle' | 'bottom', mensajito: string) {
    const toast = await this.toastController.create({
      message: mensajito,
      duration: 2500,
      position: position
    });

    await toast.present();
  }

  obtenerPasajeros(id_viaje: string ){
    console.log(id_viaje);
    
    localStorage.setItem('id_viaje', id_viaje);

  }

  verPasajeros(pasajeros: string){
    console.log(pasajeros);
    localStorage.setItem('pasajeros',pasajeros);
  }



}
