import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { BienvenidopasajeroPageRoutingModule } from './bienvenidopasajero-routing.module';

import { BienvenidopasajeroPage } from './bienvenidopasajero.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    BienvenidopasajeroPageRoutingModule
  ],
  declarations: [BienvenidopasajeroPage]
})
export class BienvenidopasajeroPageModule {}
