import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BienvenidopasajeroPage } from './bienvenidopasajero.page';

const routes: Routes = [
  {
    path: '',
    component: BienvenidopasajeroPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class BienvenidopasajeroPageRoutingModule {}
