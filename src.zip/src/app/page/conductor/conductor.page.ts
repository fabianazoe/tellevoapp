import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AlertController } from '@ionic/angular';
import { ApiService } from 'src/app/servicios/api.service';
import { ToastController } from '@ionic/angular';
import { Geolocation } from '@capacitor/geolocation';

@Component({
  selector: 'app-conductor',
  templateUrl: './conductor.page.html',
  styleUrls: ['./conductor.page.scss'],
})
export class ConductorPage implements OnInit {



  miModelo: any;

  formConductor = {
    id_viaje : "",
    destino : "",
    monto_por_persona : "",
    total_pasajeros : "",
    asientos_disponibles : "",
    latitud : "",
    longitud: "",
  }

  correoo: any;
  tipo_usuario: any;
  formBienvenido={
    texto: "",
    checkbox: false,
    radiobutton: "",
    select: "",
    datetime: ""

  }
  constructor(private activeroute: ActivatedRoute, private router: Router, private api: ApiService, private alertController: AlertController, private toastController: ToastController) {

    this.activeroute.queryParams.subscribe(params=>{
        
      if(params['correos'])
      {
        this.correoo = params['correos'];
        console.log("correo entregado: " + this.correoo)
      }
    });

   }

   async obtenerLatitud()
   {
     let ubicacion = await Geolocation.getCurrentPosition();
     let miLatitud = "Latitud: "+ubicacion.coords.latitude 
       
     this.mostrarMensaje(miLatitud)
 
   }
 
   async obtenerLongitud()
   {
     let ubicacion = await Geolocation.getCurrentPosition();
     let miLongitud =  "Longitud: "+ubicacion.coords.longitude 
       
     this.mostrarMensaje(miLongitud)
 
   }
 
   async mostrarMensaje(mensaje: string) {
     const toast = await this.toastController.create({
       message: mensaje,
       duration: 5000,
       position: 'top'
     });
 
     await toast.present();
   }
   verDatos()
   {
 
     console.log(this.formBienvenido)
   }

   registarViaje()
   {
     this.api.crearViaje(this.formConductor.id_viaje, 
       this.formConductor.destino, 
       this.formConductor.monto_por_persona, 
       this.formConductor.total_pasajeros,
       this.formConductor.asientos_disponibles,
       this.formConductor.latitud,
       this.formConductor.longitud).subscribe((res)=>{
         console.log(res)
       })
     
   }

   
  ngOnInit() {this.miModelo = {
  };


}
}