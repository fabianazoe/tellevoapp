import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-bienvenido',
  templateUrl: './bienvenido.page.html',
  styleUrls: ['./bienvenido.page.scss'],
})
export class BienvenidoPage implements OnInit {

  correoo: any;
  tipo_usuario: any;
  formBienvenido={
    texto: "",
    checkbox: false,
    radiobutton: "",
    select: "",
    datetime: ""

  }
  constructor(private activeroute: ActivatedRoute, private router: Router) {

    this.activeroute.queryParams.subscribe(params=>{
        
      if(params['correos'])
      {
        this.correoo = params['correos'];
        console.log("correo entregado: " + this.correoo)
      }
    });

   }

   

  ngOnInit() {
    
  }

  verDatos()
  {

    console.log(this.formBienvenido)



  }
 }

