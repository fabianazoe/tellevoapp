import { Component, OnInit } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { ApiService } from 'src/app/servicios/api.service';
@Component({
  selector: 'app-pasajero',
  templateUrl: './pasajero.page.html',
  styleUrls: ['./pasajero.page.scss'],
})
export class PasajeroPage implements OnInit {

  listaViajes: any[] = []
  constructor(private api : ApiService, private toastController: ToastController, private router: Router) { }

  
  ngOnInit() {
    this.ObtenerViajes()
  }
  ObtenerViajes()
  {
    this.api.obtenerViajes().subscribe((respuesta)=>{
      console.log(respuesta);
      if(respuesta.result == "No hay ningun viaje creado")
      {
        //mostrar un error
        this.presentToast('middle', respuesta.viajes)
      }
      else{
        this.listaViajes = respuesta.viajes;
        }
    
    })
  }
  async presentToast(position: 'top' | 'middle' | 'bottom', mensajito: string) {
    const toast = await this.toastController.create({
      message: mensajito,
      duration: 2500,
      position: position
    });

    await toast.present();
  }

}
