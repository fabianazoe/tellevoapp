import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ToastController } from '@ionic/angular';
import { ApiService } from 'src/app/servicios/api.service';

@Component({
  selector: 'app-rcontrasena',
  templateUrl: './rcontrasena.page.html',
  styleUrls: ['./rcontrasena.page.scss'],
})
export class RcontrasenaPage implements OnInit {

  formrContrasena: any={
    correo: String("")
  }

  miModelo: any;

  constructor(private alertController: AlertController, private router: Router, private api: ApiService, private toastController: ToastController) { }
  async presentAlert() {
    const alert = await this.alertController.create({
      header: '¡SU CODIGO DE VERIFICACIÓN PARA RECUPERAR SU CONTRASEÑA A SIDO ENVIADO EXITOSAMENTE!',
      subHeader: '',
      message: '',
      buttons: ['OK'],
    });

    await alert.present();
  }

  


  ngOnInit() {this.miModelo = {
  };
  }

  recuperarPassword(){
    this.api.recuperarPassword(
      this.formrContrasena.correo).subscribe((response)=>{
        console.log(response);
      })
    
  }


}
